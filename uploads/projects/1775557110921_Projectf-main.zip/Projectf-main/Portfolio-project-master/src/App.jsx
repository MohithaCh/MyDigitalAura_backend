import { useState } from 'react';
import './App.css';
import './theme.css';
import { ThemeProvider } from './ThemeContext';
import HomePage from './components/HomePage';
import StudentDashboard from './components/StudentDashboard';
import AdminDashboard from './components/AdminDashboard';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useState(null);

  const handleLogin = (userData) => {
    setUser(userData);
    setCurrentPage(userData.role === 'student' ? 'student' : 'admin');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage('home');
  };

  return (
    <ThemeProvider>
      <div className="app">
        {currentPage === 'home' && <HomePage onLogin={handleLogin} />}
        {currentPage === 'student' && <StudentDashboard user={user} onLogout={handleLogout} />}
        {currentPage === 'admin' && <AdminDashboard user={user} onLogout={handleLogout} />}
      </div>
    </ThemeProvider>
  );
}

export default App;
