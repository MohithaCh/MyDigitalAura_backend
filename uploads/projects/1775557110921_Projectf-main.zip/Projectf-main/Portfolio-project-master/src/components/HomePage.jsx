import { useState, useEffect, useRef } from 'react';
import { useTheme } from '../ThemeContext';
import './HomePage.css';

// Registered users stored in memory (replace with backend later)
const registeredUsers = [];

function generateCaptcha() {
  const a = Math.floor(Math.random() * 10) + 1;
  const b = Math.floor(Math.random() * 10) + 1;
  const ops = ['+', '-', '×'];
  const op = ops[Math.floor(Math.random() * ops.length)];
  let answer;
  if (op === '+') answer = a + b;
  else if (op === '-') answer = a - b;
  else answer = a * b;
  return { question: `${a} ${op} ${b} = ?`, answer };
}

function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function HomePage({ onLogin }) {
  const { theme, toggleTheme } = useTheme();
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [formData, setFormData] = useState({
    email: '', password: '', firstName: '', middleName: '',
    lastName: '', confirmPassword: '', role: 'student'
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // CAPTCHA state (login)
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const [captchaInput, setCaptchaInput] = useState('');
  const [captchaError, setCaptchaError] = useState('');

  // OTP state (register)
  const [otpSent, setOtpSent] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [otpInput, setOtpInput] = useState('');
  const [otpError, setOtpError] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [otpTimer, setOtpTimer] = useState(0);
  const timerRef = useRef(null);

  useEffect(() => {
    if (otpTimer > 0) {
      timerRef.current = setTimeout(() => setOtpTimer(t => t - 1), 1000);
    }
    return () => clearTimeout(timerRef.current);
  }, [otpTimer]);

  const refreshCaptcha = () => {
    setCaptcha(generateCaptcha());
    setCaptchaInput('');
    setCaptchaError('');
  };

  const handleSendOTP = () => {
    if (!formData.email.trim() || !/\S+@\S+\.\S+/.test(formData.email)) {
      setError('Enter a valid email to receive OTP.');
      return;
    }
    const isDuplicate = registeredUsers.find(u => u.email === formData.email);
    if (isDuplicate) {
      setError('This email is already registered. Please login.');
      return;
    }
    const otp = generateOTP();
    setOtpValue(otp);
    setOtpSent(true);
    setOtpTimer(60);
    setOtpError('');
    setError('');
    // Simulate email — show OTP in alert (replace with real API call later)
    alert(`📧 OTP sent to ${formData.email}\n\nYour OTP (simulated): ${otp}\n\n⚠️ In production this will be sent to your real email.`);
  };

  const handleVerifyOTP = () => {
    if (otpInput.trim() === otpValue) {
      setOtpVerified(true);
      setOtpError('');
      setSuccess('✅ Email verified successfully!');
    } else {
      setOtpError('❌ Incorrect OTP. Please try again.');
    }
  };

  const handleResendOTP = () => {
    const otp = generateOTP();
    setOtpValue(otp);
    setOtpTimer(60);
    setOtpInput('');
    setOtpError('');
    alert(`📧 New OTP sent to ${formData.email}\n\nYour OTP (simulated): ${otp}`);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (authMode === 'login') {
      if (!formData.email.trim()) { setError('Email is required!'); return; }
      if (!formData.password.trim()) { setError('Password is required!'); return; }

      // CAPTCHA check
      if (captchaInput.trim() === '') { setCaptchaError('Please solve the CAPTCHA.'); return; }
      if (parseInt(captchaInput) !== captcha.answer) {
        setCaptchaError('❌ Wrong CAPTCHA answer. Try again.');
        refreshCaptcha();
        return;
      }

      // Check if user exists
      const existingUser = registeredUsers.find(
        u => u.email === formData.email && u.password === formData.password
      );
      if (!existingUser) {
        setError('Invalid email or password. Please register first.');
        refreshCaptcha();
        return;
      }
      onLogin({ ...existingUser });
    }

    if (authMode === 'register') {
      if (!formData.firstName.trim()) { setError('First name is required!'); return; }
      if (!formData.lastName.trim()) { setError('Last name is required!'); return; }
      if (!formData.email.trim()) { setError('Email is required!'); return; }
      if (!/\S+@\S+\.\S+/.test(formData.email)) { setError('Enter a valid email address!'); return; }
      if (!formData.password.trim()) { setError('Password is required!'); return; }
      if (formData.password.length < 6) { setError('Password must be at least 6 characters!'); return; }
      if (formData.password !== formData.confirmPassword) { setError('Passwords do not match!'); return; }

      // Duplicate email check
      const isDuplicate = registeredUsers.find(u => u.email === formData.email);
      if (isDuplicate) { setError('This email is already registered. Please login.'); return; }

      // OTP verification required
      if (!otpSent) { setError('Please send OTP to verify your email first.'); return; }
      if (!otpVerified) { setError('Please verify your email OTP before registering.'); return; }

      const name = `${formData.firstName} ${formData.middleName} ${formData.lastName}`.trim();
      const newUser = { ...formData, name, id: Date.now() };
      registeredUsers.push(newUser);
      setSuccess('✅ Account created! You can now login.');
      setAuthMode('login');
      setOtpSent(false);
      setOtpVerified(false);
      setOtpInput('');
      setOtpValue('');
      refreshCaptcha();
      setFormData({ email: '', password: '', firstName: '', middleName: '', lastName: '', confirmPassword: '', role: 'student' });
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
    setSuccess('');
  };

  const handleOpenAuth = (mode) => {
    setShowAuth(true);
    setAuthMode(mode);
    setError('');
    setSuccess('');
    setOtpSent(false);
    setOtpVerified(false);
    setOtpInput('');
    setOtpValue('');
    setCaptchaInput('');
    setCaptchaError('');
    refreshCaptcha();
    setFormData({ email: '', password: '', firstName: '', middleName: '', lastName: '', confirmPassword: '', role: 'student' });
  };

  return (
    <div className="home-page">
      <nav className="navbar">
        <div className="logo">🎓 MyDigitalAura</div>
        <div className="nav-buttons">
          <button className="theme-toggle" onClick={toggleTheme}>
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>
          <button onClick={() => handleOpenAuth('login')}>Login</button>
          <button onClick={() => handleOpenAuth('register')}>Register</button>
        </div>
      </nav>

      <div className="hero">
        <h1>Build Your Academic Portfolio</h1>
        <p>Showcase your projects, track progress, and get feedback from educators</p>
      </div>

      <div className="features">
        <div className="feature-card">
          <div className="feature-icon">👨🎓</div>
          <h3>Student Dashboard</h3>
          <p>Upload projects, track milestones, and view feedback</p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">👩🏫</div>
          <h3>Admin Dashboard</h3>
          <p>Review submissions, provide feedback, and approve projects</p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">📊</div>
          <h3>Progress Tracking</h3>
          <p>Monitor your academic journey with detailed analytics</p>
        </div>
      </div>

      {showAuth && (
        <div className="auth-modal" onClick={() => setShowAuth(false)}>
          <div className="auth-container" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => setShowAuth(false)}>×</button>
            <div style={{ flex: 1 }}>
              <div className="auth-tabs">
                <button
                  className={`auth-tab ${authMode === 'login' ? 'active' : ''}`}
                  onClick={() => { setAuthMode('login'); setError(''); setSuccess(''); refreshCaptcha(); }}
                >
                  🔐 Login
                </button>
                <button
                  className={`auth-tab ${authMode === 'register' ? 'active' : ''}`}
                  onClick={() => { setAuthMode('register'); setError(''); setSuccess(''); setOtpSent(false); setOtpVerified(false); setOtpInput(''); }}
                >
                  📝 Register
                </button>
              </div>

              <form className="auth-form" onSubmit={handleSubmit}>
                {error && (
                  <div style={{ color: '#dc3545', marginBottom: '1rem', padding: '0.7rem 1rem', background: 'rgba(220,53,69,0.1)', borderRadius: '8px', border: '1px solid rgba(220,53,69,0.3)', fontSize: '0.9rem' }}>
                    {error}
                  </div>
                )}
                {success && (
                  <div style={{ color: '#28a745', marginBottom: '1rem', padding: '0.7rem 1rem', background: 'rgba(40,167,69,0.1)', borderRadius: '8px', border: '1px solid rgba(40,167,69,0.3)', fontSize: '0.9rem' }}>
                    {success}
                  </div>
                )}

                {authMode === 'register' && (
                  <>
                    <div className="form-group">
                      <label>First Name</label>
                      <input type="text" name="firstName" placeholder="Enter your first name" value={formData.firstName} onChange={handleChange} required />
                    </div>
                    <div className="form-group">
                      <label>Middle Name</label>
                      <input type="text" name="middleName" placeholder="Enter your middle name (optional)" value={formData.middleName} onChange={handleChange} />
                    </div>
                    <div className="form-group">
                      <label>Last Name</label>
                      <input type="text" name="lastName" placeholder="Enter your last name" value={formData.lastName} onChange={handleChange} required />
                    </div>
                  </>
                )}

                <div className="form-group">
                  <label>Email Address</label>
                  <input type="email" name="email" placeholder="Enter your email" value={formData.email} onChange={handleChange} required />
                </div>

                {/* OTP Section for Register */}
                {authMode === 'register' && (
                  <div className="otp-section">
                    <div className="otp-header">
                      <span>📧 Email Verification</span>
                      {otpVerified && <span className="otp-verified-badge">✅ Verified</span>}
                    </div>

                    {!otpVerified && (
                      <>
                        {!otpSent ? (
                          <button type="button" className="otp-send-btn" onClick={handleSendOTP}>
                            Send OTP to Email
                          </button>
                        ) : (
                          <div className="otp-input-row">
                            <input
                              type="text"
                              placeholder="Enter 6-digit OTP"
                              value={otpInput}
                              onChange={(e) => { setOtpInput(e.target.value); setOtpError(''); }}
                              maxLength={6}
                              className="otp-input"
                            />
                            <button type="button" className="otp-verify-btn" onClick={handleVerifyOTP}>
                              Verify
                            </button>
                          </div>
                        )}
                        {otpError && <p className="otp-error">{otpError}</p>}
                        {otpSent && !otpVerified && (
                          <div className="otp-resend-row">
                            {otpTimer > 0
                              ? <span className="otp-timer">Resend OTP in {otpTimer}s</span>
                              : <button type="button" className="otp-resend-btn" onClick={handleResendOTP}>🔄 Resend OTP</button>
                            }
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}

                <div className="form-group">
                  <label>Password</label>
                  <input type="password" name="password" placeholder="Enter your password" value={formData.password} onChange={handleChange} required />
                </div>

                {authMode === 'register' && (
                  <div className="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="confirmPassword" placeholder="Re-enter your password" value={formData.confirmPassword} onChange={handleChange} required />
                  </div>
                )}

                <div className="form-group">
                  <label>Role</label>
                  <select name="role" value={formData.role} onChange={handleChange}>
                    <option value="student">👨🎓 Student</option>
                    <option value="admin">👩🏫 Admin (Teacher/Institution)</option>
                  </select>
                </div>

                {/* CAPTCHA Section for Login */}
                {authMode === 'login' && (
                  <div className="captcha-section">
                    <div className="captcha-header">🔒 Security Check</div>
                    <div className="captcha-box">
                      <span className="captcha-question">{captcha.question}</span>
                      <button type="button" className="captcha-refresh" onClick={refreshCaptcha} title="Refresh CAPTCHA">🔄</button>
                    </div>
                    <input
                      type="number"
                      placeholder="Enter your answer"
                      value={captchaInput}
                      onChange={(e) => { setCaptchaInput(e.target.value); setCaptchaError(''); }}
                      className="captcha-input"
                    />
                    {captchaError && <p className="captcha-error">{captchaError}</p>}
                  </div>
                )}

                <button type="submit" className="submit-btn">
                  {authMode === 'login' ? '🔐 Login' : '📝 Create Account'}
                </button>

                <div style={{ textAlign: 'center', marginTop: '1rem', color: '#6c757d' }}>
                  {authMode === 'login' ? (
                    <p>Don't have an account? <span onClick={() => { setAuthMode('register'); setError(''); setSuccess(''); }} style={{ color: '#667eea', cursor: 'pointer', fontWeight: '600' }}>Register</span></p>
                  ) : (
                    <p>Already have an account? <span onClick={() => { setAuthMode('login'); setError(''); setSuccess(''); refreshCaptcha(); }} style={{ color: '#667eea', cursor: 'pointer', fontWeight: '600' }}>Login</span></p>
                  )}
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      <footer className="footer">
        <p>© Copyright {new Date().getFullYear()} Swetha, Poojitha, Mohitha</p>
      </footer>
    </div>
  );
}

export default HomePage;
